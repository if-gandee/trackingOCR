#include "stdafx.h"
#include "single_functions.h"
#include "util_cgal.h"

namespace python_geom
{

	_NS_UTILITY::bp::object py_barycentric_coordinate(np::ndarray tris, np::ndarray pts)
	{		
		MATRIX_d _tris;
		MATRIX_d _pts;
		to_matrix(tris, _tris);
		to_matrix(pts, _pts);

		assert_python(_tris.size() % 9 ==0, "wrong format for tris");
		assert_python(_pts.size() % 3 ==0, "wrong format for pts");
		assert_python(_tris.size() / 9 == _pts.size() / 3, "number of triangles does not match with the number of points");

		MATRIX_d output(_pts.rows(), 3);
		auto _trdata = _tris.data();
		int k = 0;
		for (int i = 0; i < _tris.rows(); i++)
		{
			auto data = _trdata + i * 9;
			POINT_3 v1(data[0], data[1], data[2]);
			POINT_3 v2(data[3], data[4], data[5]);
			POINT_3 v3(data[6], data[7], data[8]);
			POINT_3 p(_pts(i, 0), _pts(i, 1), _pts(i, 2));

			TRI_3 triangle(v1, v2, v3);
			auto bc = compute_barycentric_coordinate(triangle, p);
			output(i, 0) = bc.x();
			output(i, 1) = bc.y();
			output(i, 2) = bc.z();
		}
		return to_ndarray(output);
	}

}