#pragma once

#include "TriangularMesh.h"
#include "MeshSearcher.h"
#include "util_python.h"

namespace python_geom
{
	using namespace _NS_UTILITY;
	class PyTriangularMesh
	{
	private:
		std::shared_ptr<fastgeom::TriangularMesh> m_mesh;
		std::shared_ptr<fastgeom::MeshSearcher> m_searcher;

	public:
		void py_set_data(np::ndarray vertices, np::ndarray faces);

		/// <summary>
		/// find closest point for each input point
		/// </summary>
		/// <param name="pts">the query points</param>
		/// <returns>(nnpts, idxtri, bcpts), where
		/// nnpts[i] is the closest point, idxtri[i] is the index
		/// of the triangle that contains nnpts[i], and
		/// bcpts[i] is the barycentric coordinate of nnpts[i]</returns>
		bp::object py_closest_point(np::ndarray pts);

		/// <summary>
		/// find the first hit points for given rays
		/// </summary>
		/// <param name="ray_p0">nx3 matrix, origins of the rays</param>
		/// <param name="ray_dir">nx3 matrix, directions of the rays</param>
		/// <returns>(hitpts, idxtri, bcpts), where hitpts[i] is the hit point for i-th ray,
		/// and idxtri[i] is the index of the triangle that contains hitpts[i].		
		/// If a ray does not hit any triangle, idxtri[i]=-1.
		/// bcpts[i] is the barycentric coordinate of hitpts[i]</returns>
		bp::object py_ray_intersect_first(np::ndarray ray_p0, np::ndarray ray_dir);

		np::ndarray py_get_vertices();
		np::ndarray py_get_faces();

	public:
		PyTriangularMesh();
		virtual ~PyTriangularMesh();
	};
}


