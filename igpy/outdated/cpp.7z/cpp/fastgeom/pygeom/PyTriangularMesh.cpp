#include "stdafx.h"
#include "PyTriangularMesh.h"
#include "util_eigen_python.h"

namespace python_geom
{
	void PyTriangularMesh::py_set_data(np::ndarray vertices, np::ndarray faces)
	{
		//create mesh
		MATRIX_d v;
		MATRIX_i f;
		to_matrix(vertices, v);
		to_matrix(faces, f);
		fastgeom::TriangularMesh::init_with_vertex_face(*m_mesh, v, f);

		//create search structure
		fastgeom::MeshSearcher::init_with_triangular_mesh(*m_searcher, *m_mesh);
	}

	bp::object PyTriangularMesh::py_closest_point(np::ndarray pts)
	{
		MATRIX_d _pts;
		to_matrix(pts, _pts);

		VECTOR_i _idxtri;
		MATRIX_d _nnpts;
		MATRIX_d _bcpts;
		m_searcher->find_closest_point(_pts, &_nnpts, &_idxtri, &_bcpts);

		np::ndarray idxtri = to_ndarray(_idxtri);
		np::ndarray nnpts = to_ndarray(_nnpts);
		np::ndarray bcpts = to_ndarray(_bcpts);
		return bp::make_tuple(nnpts, idxtri, bcpts);
	}

	bp::object PyTriangularMesh::py_ray_intersect_first(np::ndarray ray_p0, np::ndarray ray_dir)
	{
		MATRIX_d _ray_p0;
		MATRIX_d _ray_dir;
		to_matrix(ray_p0, _ray_p0);
		to_matrix(ray_dir, _ray_dir);

		assert_python(_ray_p0.size() % 3 == 0, "ray_p0 format is wrong");
		assert_python(_ray_dir.size() % 3 == 0, "ray_dir format is wrong");
		assert_python(_ray_p0.size() / 3 == _ray_dir.size() / 3, "number of ray_p0 does not match with number of ray_dir");

		MATRIX_d _hitpts;
		VECTOR_i _idxtri;
		MATRIX_d _bcpts;
		m_searcher->intersect_with_ray_first(_ray_p0, _ray_dir, &_hitpts, &_idxtri, &_bcpts);

		auto hitpts = to_ndarray(_hitpts);
		auto idxtri = to_ndarray(_idxtri);
		auto bcpts = to_ndarray(_bcpts);
		return bp::make_tuple(hitpts, idxtri, bcpts);

		//auto data_p0 = _ray_p0.data();
		//auto data_dir = _ray_dir.data();
		//int n_ray = _ray_p0.size() / 3;
		//for (int i = 0; i < n_ray; i++)
		//{
		//	POINT_3 p(data_p0[3 * i], data_p0[3 * i + 1], data_p0[3 * i + 2]);
		//	VEC_3 dir(data_dir[3 * i], data_dir[3 * i + 1], data_dir[3 * i + 2]);
		//	RAY_3 ray(p, p + dir); //use p+dir instead of dir to let CGAL normalize the ray direction
		//	m_searcher
		//}
	}

	np::ndarray PyTriangularMesh::py_get_vertices()
	{
		MATRIX_d v = m_mesh->get_vertices();
		return to_ndarray(v);
	}

	np::ndarray PyTriangularMesh::py_get_faces()
	{
		auto f = m_mesh->get_faces();
		return to_ndarray(f);
	}

	PyTriangularMesh::PyTriangularMesh()
	{
		init_ptr_with_default_constructor(m_mesh);
		init_ptr_with_default_constructor(m_searcher);
	}


	PyTriangularMesh::~PyTriangularMesh()
	{
	}
}

