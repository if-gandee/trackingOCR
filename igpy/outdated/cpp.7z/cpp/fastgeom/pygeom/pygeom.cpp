// pygeom.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "PyTriangularMesh.h"
#include "single_functions.h"

using namespace python_geom;

const char* doc_py_set_data =
"initialize the triangular mesh with vertices and faces.\n\n"
"parameters\n"
"-----------------------\n"
"vertices\n"
"\t the vertices\n"
"faces\n"
"\t the faces\n"
"\n"
"return\n"
"-----------------------\n"
"meshobj\n"
"\t A TriangularMesh object with search structure\n";

const char* doc_find_closest_points =
"find closest point on the mesh for each query point.\n\n"
"parameter\n"
"---------------------------\n"
"pts\n"
"\t nx3 points\n"
"\n"
"return\n"
"---------------------\n"
"nnpts\n"
"\t closest points. nnpts[i] is the closest point from pts[i] to the mesh\n"
"idxtri\n"
"\t idxtri[i] is the index of the triangle that contains nnpts[i]\n"
"bcpts\n"
"\t bcpts[i] is the barycentric coordinate of nnpts[i] on triangle idxtri[i]\n";

const char* doc_barycentric_coordinate =
"Find barycentric coordinates for given triangles and points."
"Specifically, the barycentric coordinate of pts[i] on triangles[i] will be computed and returned.\n\n"
"parameter\n"
"-------------------\n"
"triangles\n"
"\t nx9 matrix, each row is (x1,y1,z1,x2,y2,z2,x3,y3,z3), the 3 vertices of the triangle.\n"
"pts\n"
"\t nx3 matrix, each row is a query point.\n"
"\n"
"return\n"
"--------------------\n"
"bcpts\n"
"\t bcpts[i] is the barycentric coordinate of pts[i] on triangles[i]\n";

const char* doc_intersect_with_ray_first =
"Find first intersection point for each input ray with the mesh.\n\n"
"parameter\n"
"--------------------\n"
"p0\n"
"\t nx3 matrix, origins of the rays\n"
"dirs\n"
"\t nx3 matrix, directions of the rays\n"
"\n"
"return\n"
"------------------\n"
"hitpts\n"
"\t points on the mesh hit by the rays. hitpts[i] is for i-th ray\n"
"idxtri\n"
"\t indices of the triangles hit by the rays. idxtri[i]<0 iff the i-th ray does not hit any triangle.\n"
"bcpts\n"
"\t barycentric coordinates of the hitpts.\n";


BOOST_PYTHON_MODULE(pygeom)
{
	bp::docstring_options docopt(true, true, false);
	np::initialize();
	bp::class_<PyTriangularMesh>("TriangularMesh", "a data structure that contains a triangular mesh with search structure")
		.def("set_data", &PyTriangularMesh::py_set_data, (bp::arg("vertices"), bp::arg("faces")), doc_py_set_data)
		.def("find_closest_points", &PyTriangularMesh::py_closest_point, (bp::arg("pts")), doc_find_closest_points)
		.def("intersect_with_ray_first", &PyTriangularMesh::py_ray_intersect_first, (bp::arg("p0"), bp::arg("dirs")), doc_intersect_with_ray_first)
		.def("get_vertices", &PyTriangularMesh::py_get_vertices)
		.def("get_faces", &PyTriangularMesh::py_get_faces);
	bp::def("calc_barycentric_coordinate", py_barycentric_coordinate, (bp::arg("triangles"), bp::arg("pts")), doc_barycentric_coordinate);

}
