#pragma once
#include "stdafx.h"
#include "util_eigen_python.h"

namespace python_geom
{
	using namespace _NS_UTILITY;
	/// <summary>
	/// Compute barycentric coordinate for each point in each triangle.
	/// Return the barycentric coordinate of pts[i] on tris[i].
	/// </summary>
	/// <param name="tris">nx9 matrix, each row is the 3 triangle vertices concatenated</param>
	/// <param name="pts">nx3 matrix, each point is a point to query for barycentric coordinate</param>
	/// <returns>nx3 matrix, such that output[i] is the barycentric coordinate of pts[i] on tris[i]</returns>
	bp::object py_barycentric_coordinate(np::ndarray tris, np::ndarray pts);
};