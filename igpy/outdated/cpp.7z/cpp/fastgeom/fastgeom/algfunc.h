#pragma once
#include "stdafx.h"
#include "globaldefs.h"
#include <CGAL/Monge_via_jet_fitting.h>
#include <iostream>

namespace fastgeom
{
	using namespace _NS_UTILITY;
	using MongeFitter = CGAL::Monge_via_jet_fitting<KERNEL>;
	using MongeForm = MongeFitter::Monge_form;

	/// <summary>
	/// Fit quadric to the points
	/// </summary>
	/// <param name="pts">nx3, the points</param>
	/// <param name="idx_origin">index of the point that will be used as origin of the pca basis</param>
	/// <param name="out_origin">3x1, the origin of the pca basis </param>
	/// <param name="out_basis">3x3, pca basis, each row is an axis</param>
	/// <param name="out_coef">nx1 monge coefficients</param>
	/// <param name="d_monge">degree of the monge surface, can be 2,3,4 </param>
	void fit_quadric(const MATRIX_d& pts, int idx_origin, VECTOR_d* out_origin, 
		MATRIX_d* out_basis, VECTOR_d* out_coef, int d_monge = 4)
	{
		int d_fit = 4;
		assert_throw(d_monge <= 4, "monge function degree must be equal or less than 4");

		// create point list
		auto in_points = to_point_list_3(pts);

		// note that in_points[0] will be used as the origin of the monge surface
		// so we put the origin at the beginning
		std::swap(*in_points.begin(), *(in_points.begin() + idx_origin));

		MongeFitter monge_fit;
		auto monge_form = monge_fit(in_points.begin(), in_points.end(), d_fit, d_monge);

		if (out_origin)
		{
			out_origin->resize(3);
			auto p0 = monge_form.origin();
			(*out_origin)(0) = p0.x();
			(*out_origin)(1) = p0.y();
			(*out_origin)(2) = p0.z();
		}

		if (out_basis)
		{
			out_basis->resize(3, 3);
			auto d1 = monge_form.maximal_principal_direction();
			auto d2 = monge_form.minimal_principal_direction();
			auto d3 = monge_form.normal_direction();
			
			(*out_basis) << d1.x(), d1.y(), d1.z(),
				d2.x(), d2.y(), d2.z(),
				d3.x(), d3.y(), d3.z();
		}

		if (out_coef)
		{
			auto coefs = monge_form.coefficients();
			*out_coef = Eigen::Map<VECTOR_d>(coefs.data(), coefs.size());
		}

		//OUTPUT on std::cout
		//CGAL::set_pretty_mode(std::cout);
		//std::cout << "vertex : " << in_points[0] << std::endl
		//	<< "number of points used : " << in_points.size() << std::endl
		//	<< monge_form;
		//std::cout << "condition_number : " << monge_fit.condition_number() << std::endl
		//	<< "pca_eigen_vals and associated pca_eigen_vecs :" << std::endl;
		//for (int i = 0; i < 3; i++)
		//	std::cout << monge_fit.pca_basis(i).first << std::endl
		//	<< monge_fit.pca_basis(i).second << std::endl;
	}
};
