#include "stdafx.h"
#include "TriangularMesh.h"
#include "util_eigen.h"
#include "KDTreeSearcher.h"

#include <iostream>
#include <utility>
using namespace std;
using tinyobj::shape_t;
using tinyobj::material_t;
using tinyobj::attrib_t;
using namespace _NS_UTILITY;
using namespace fastgeom;

class testclass
{
public:
	int x;

	int func() { return 0; }
};
int main()
{
	string objfile = "C:/Users/igame/Desktop/model/mongefit.obj";
	auto obj = TriangularMesh::init_with_objfile(objfile);
	MATRIX_d vertices = obj.get_vertices();
	MATRIX_d v2(vertices.rows(), vertices.cols() * 2);
	v2 << vertices, vertices;
	vector<int> idx_row = { 1,3,4,5 };

	MATRIX_d query_pts = get_sub_matrix(v2, idx_row, -1);

	KDTREE_STATIC_nd kdtree = KDTREE_STATIC_nd::init_with_points(v2);
	MATRIX_d distmat;
	MATRIX_i indexmat;
	kdtree.query(query_pts, 10, &distmat, &indexmat);

	cout << query_pts << endl;
	cout << indexmat << endl;
	cout << distmat << endl;

	return 0;
}