#pragma once
#include "stdafx.h"
#include "TriangularMesh.h"
#include "util_eigen.h"
#include "KDTreeSearcher.h"
#include "MeshSearcher.h"
#include "util_cpp.h"
#include "util_eigen.h"
#include "helpers.h"

#include <iostream>
#include <utility>
using namespace std;
using tinyobj::shape_t;
using tinyobj::material_t;
using tinyobj::attrib_t;
using namespace _NS_UTILITY;
using namespace fastgeom;

class testclass
{
public:
	int x;

	int func() { return 0; }
};

using namespace std;
int main()
{
	string ptsfile = "D:\\model.obj";
	auto name2mesh = load_obj_as_name2mesh(ptsfile);
	auto obj_ground = name2mesh["ground"];
	auto obj_points = name2mesh["points"];

	auto ms = MeshSearcher::init_with_triangular_mesh(obj_ground);
	cout << obj_ground.get_vertices() << endl << endl;
	cout << obj_points.get_vertices() << endl << endl;

	MATRIX_d nnpts;
	VECTOR_i idxtri;
	MATRIX_d bcpts;
	ms.find_closest_point(obj_points.get_vertices(), &nnpts, &idxtri, &bcpts);
	cout << obj_ground.get_vertices() << endl << endl;
	cout << nnpts << endl;
	cout << endl;
	cout << bcpts << endl;

	save_matrix("d:/ground_v", obj_ground.get_vertices());
	save_matrix("d:/ground_f", obj_ground.get_faces());
	save_matrix("d:/points", obj_points.get_vertices());
	save_matrix("d:/nnpts", nnpts);
	save_matrix("d:/idxtri", idxtri);
	save_matrix("d:/bcpts", bcpts);

	return 0;
}