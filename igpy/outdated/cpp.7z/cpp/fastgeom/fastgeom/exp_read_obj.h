#include "stdafx.h"

#include <iostream>
using namespace std;
using tinyobj::shape_t;
using tinyobj::material_t;
using tinyobj::attrib_t;
int main()
{
	string objfile = "d:/test.obj";
	vector<shape_t> shapes;
	vector<material_t> materials;
	attrib_t attrib;
	string err;

	bool ret = tinyobj::LoadObj(&attrib, &shapes, &materials, &err, objfile.c_str());

	cout << "total vertices = " << attrib.vertices.size() / 3 << endl << endl;

	// face structure
	for (auto x : shapes)
	{
		cout << x.name << endl;
		int k = 0;
		for (auto n : x.mesh.num_face_vertices)
		{
			for (int i = 0; i < n; i++)
			{
				auto vn = x.mesh.indices[k + i].normal_index;
				auto v = x.mesh.indices[k + i].vertex_index;
				auto vt = x.mesh.indices[k + i].texcoord_index;

				printf("%d/%d/%d, ", v + 1, vt + 1, vn + 1);
			}
			printf("\n");
			k += n;
		}
		cout << endl;
	}

	return 0;
}