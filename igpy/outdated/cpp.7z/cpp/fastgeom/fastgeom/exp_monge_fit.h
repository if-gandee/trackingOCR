#include "stdafx.h"
#include "TriangularMesh.h"
#include "util_eigen.h"
#include "algfunc.h"

#include <iostream>
using namespace std;
using tinyobj::shape_t;
using tinyobj::material_t;
using tinyobj::attrib_t;
using namespace _NS_UTILITY;
using namespace fastgeom;
int main()
{
	string objfile = "C:/Users/igame/Desktop/model/mongefit.obj";
	auto obj = TriangularMesh::init_with_objfile(objfile);
	MATRIX_d vertices = obj.get_vertices();

	MATRIX_d pca_basis;
	VECTOR_d coefs;
	VECTOR_d pca_origin;
	int idx_origin;
	vertices.col(2).maxCoeff(&idx_origin);
	fit_quadric(vertices, idx_origin, &pca_origin, &pca_basis, &coefs, 4);

	save_matrix("d:/pca_origin", pca_origin);
	save_matrix("d:/pca_basis", pca_basis);
	save_matrix("d:/coefs", coefs);
	save_matrix("d:/points", vertices);

	return 0;
}