#include "stdafx.h"
#include "TriangularMesh.h"
#include "util_obj_eigen.h"
#include <iostream>
#include <exception>
using namespace std;
namespace fastgeom
{

	void TriangularMesh::update_cgal_mesh()
	{
		//cout << "making cgal mesh" << endl;
		auto pts = to_point_list_3(*m_vertices);
		auto fcs = to_face_list(*m_faces);
		m_trimesh = std::make_shared<TRIMESH_3>();
		make_trimesh(pts, fcs, m_trimesh.get());
	}

	TriangularMesh::TriangularMesh()
	{
		init_ptr_with_default_constructor(m_name);
		init_ptr_with_default_constructor(m_vertices);
		init_ptr_with_default_constructor(m_faces);
		init_ptr_with_default_constructor(m_tex_vertices);
		init_ptr_with_default_constructor(m_tex_faces);
		init_ptr_with_default_constructor(m_normal_vertices);
		init_ptr_with_default_constructor(m_normal_faces);
		init_ptr_with_default_constructor(m_texture_image);
	}


	TriangularMesh::~TriangularMesh()
	{
	}

	TriangularMesh TriangularMesh::clone() const
	{
		TriangularMesh obj;
		*obj.m_vertices = *m_vertices;
		*obj.m_faces = *m_faces;
		*obj.m_name = *m_name;
		*obj.m_normal_faces = *m_normal_faces;
		*obj.m_normal_vertices = *m_normal_vertices;
		*obj.m_tex_faces = *m_tex_faces;
		*obj.m_tex_vertices = *m_tex_vertices;

		if(m_trimesh) //the model has cgal mesh, need to update it
			obj.update_cgal_mesh();
		return obj;
	}

	void TriangularMesh::save_obj(std::string filename) const
	{
		throw std::logic_error("not implemented");
	}

	void TriangularMesh::init_with_objfile(TriangularMesh& output, std::string objfile)
	{
		auto mesh = load_obj_single_mesh(objfile);
		// create object
		init_with_vertex_face(output, mesh.vertices, mesh.faces, 
			&mesh.uv, &mesh.uv_faces,
			&mesh.normals, &mesh.normal_faces);
		output.set_name(mesh.name);
	}

	TriangularMesh TriangularMesh::init_with_objfile(std::string objfile)
	{
		TriangularMesh output;
		init_with_objfile(output, objfile);
		return output;
	}

	void TriangularMesh::init_with_vertex_face(
		TriangularMesh& output,
		const MATRIX_d& vertices, const MATRIX_i& faces, 
		const MATRIX_d* uv /*= 0*/, const MATRIX_i* uv_face /*= 0*/, 
		const MATRIX_d* normals /*=0*/, const MATRIX_i* normal_face /*=0*/)
	{
		TriangularMesh& obj = output;
		*obj.m_vertices = vertices;
		*obj.m_faces = faces;
		if (uv)
		{
			assert_throw(uv_face, "uv is provided but uv_face is missing");
			*obj.m_tex_vertices = *uv;
			*obj.m_tex_faces = *uv_face;
		}

		if (normals)
		{
			assert_throw(normal_face, "normal is provided by normal_face is missing");
			*obj.m_normal_vertices = *normals;
			*obj.m_normal_faces = *normal_face;
		}
	}

}

