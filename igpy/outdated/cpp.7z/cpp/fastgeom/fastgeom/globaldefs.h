#pragma once

#include "util_eigen.h"
#include <memory>

namespace fastgeom
{
	using namespace _NS_UTILITY;
	
	/// <summary>
	/// This type of object is considered heavy, and therefore using = to copy
	/// will only copy as a reference, you must call clone() to truely copy the object.
	/// </summary>
	template<typename T>
	class HeavyObject
	{
	public:
		virtual T clone() const = 0;
	};

	/// <summary>
	/// use this function to initialize a shared_ptr without specifying its data type.
	/// </summary>
	template<typename T>
	void init_ptr_with_default_constructor(std::shared_ptr<T>& ptr)
	{
		ptr = std::make_shared<T>();
	}
}