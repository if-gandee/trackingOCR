#include "stdafx.h"
#include "helpers.h"
#include "util_common.h"
#include "util_obj_eigen.h"

using namespace std;
namespace fastgeom
{
	std::vector<TriangularMesh> load_obj_as_meshlist(std::string filename)
	{
		std::vector<TriangularMesh> output;
		auto meshlist = load_obj_multi_mesh(filename);
		for (auto& m : meshlist)
		{
			TriangularMesh tmesh;
			TriangularMesh::init_with_vertex_face(tmesh,
				m.vertices, m.faces, &m.uv, &m.uv_faces,
				&m.normals, &m.normal_faces);
			tmesh.set_name(m.name);
			output.push_back(tmesh);
		}
		return output;
	}

	std::map<std::string, TriangularMesh> load_obj_as_name2mesh(std::string filename)
	{
		auto meshlist = load_obj_as_meshlist(filename);
		std::map<std::string, TriangularMesh> output;
		for (auto& x : meshlist)
		{
			output[x.get_name()] = x;
		}
		return output;
	}
}