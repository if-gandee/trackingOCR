#include "stdafx.h"
#include "MeshSearcher.h"
#include "util_cgal_eigen.h"
#include <CGAL/Barycentric_coordinates_2/Triangle_coordinates_2.h>

using namespace std;
namespace fastgeom
{
	void MeshSearcher::update_query_structure()
	{
		//update trilist
		const auto& v = m_mesh->get_vertices();
		const auto& f = m_mesh->get_faces();

		auto pts = to_point_list_3(v);
		m_trilist->resize(f.rows());
		for (size_t i = 0; i < f.rows(); i++)
		{
			int k1 = f(i, 0);
			int k2 = f(i, 1);
			int k3 = f(i, 2);
			TRI_3 tri(pts[k1], pts[k2], pts[k3]);
			m_trilist->at(i) = tri;
		}

		//create aabb tree
		m_aabb_tree = make_shared<FACETREE_3>(m_trilist->begin(), m_trilist->end());
		m_aabb_tree->accelerate_distance_queries();
	}

	void MeshSearcher::set_mesh(const TriangularMesh& mesh, bool update /*= true*/)
	{
		m_mesh = &mesh;
		m_own_mesh = nullptr;

		if (update)
			update_query_structure();
	}

	void MeshSearcher::find_closest_point(const MATRIX_d& pts, MATRIX_d* out_nnpts, VECTOR_i* out_idxtri /*= 0*/, MATRIX_d* out_bc_pts /*=0*/)
	{
		assert_throw(m_aabb_tree != nullptr, "cannot query before aabb tree is built");
		auto ptslist = to_point_list_3(pts);

		//resulting nearest points
		std::vector<POINT_3> nnpts(ptslist.size());

		//result: index of triangle where nearest points lie
		std::vector<int> idxtri(ptslist.size());

		for (size_t i = 0; i < ptslist.size(); i++)
		{
			auto p = ptslist[i];
			auto res = m_aabb_tree->closest_point_and_primitive(p);
			nnpts[i] = res.first;
			idxtri[i] = res.second - m_trilist->begin();
		}

		//compute barycentric coordinate
		typedef CGAL::Barycentric_coordinates::Triangle_coordinates_2<KERNEL> BC_COMPUTE;
		std::vector<POINT_3> bcpts(ptslist.size());
		for (size_t i = 0; i < ptslist.size(); i++)
		{
			auto& tri = m_trilist->at(idxtri[i]);
			auto& p = nnpts[i];
			bcpts[i] = compute_barycentric_coordinate(tri, p);
		}

		if (out_nnpts)
			*out_nnpts = to_matrix(nnpts);
		if (out_idxtri)
			*out_idxtri = to_vector(idxtri);
		if (out_bc_pts)
			*out_bc_pts = to_matrix(bcpts);
	}

	void MeshSearcher::intersect_with_ray_first(const MATRIX_d& p0, const MATRIX_d& dirs, 
		MATRIX_d* out_hitpts, VECTOR_i* out_idxtri, MATRIX_d* out_bcpts)
	{
		assert_throw(p0.rows() == dirs.rows(), "number of p0 does not match number of dirs");
		MATRIX_d hitpts(p0.rows(),3);
		VECTOR_i idxtri(p0.rows());
		MATRIX_d bcpts(p0.rows(), 3);
		for (int i = 0; i < p0.rows(); i++)
		{
			POINT_3 p(p0(i, 0), p0(i, 1), p0(i, 2));
			VEC_3 d(dirs(i, 0), dirs(i, 1), dirs(i, 2));
			RAY_3 ray(p, p + d);
			POINT_3 res_point(0, 0, 0);
			int res_idxtri;
			intersect_with_ray_first(ray, &res_point, &res_idxtri);
			hitpts(i, 0) = res_point.x();
			hitpts(i, 1) = res_point.y();
			hitpts(i, 2) = res_point.z();
			idxtri(i) = res_idxtri;

			//compute barycentric coordinate
			POINT_3 res_bc(0, 0, 0);
			if (res_idxtri >= 0)
				res_bc = compute_barycentric_coordinate(m_trilist->at(res_idxtri), res_point);
			bcpts(i, 0) = res_bc.x();
			bcpts(i, 1) = res_bc.y();
			bcpts(i, 2) = res_bc.z();
		}

		if (out_hitpts)
			*out_hitpts = hitpts;
		if (out_idxtri)
			*out_idxtri = idxtri;
		if (out_bcpts)
			*out_bcpts = bcpts;
	}

	void MeshSearcher::intersect_with_ray_first(const RAY_3& ray, POINT_3* out_hitpoint, int* out_idxtri)
	{
		auto res = m_aabb_tree->first_intersection(ray);

		POINT_3 res_point(0, 0, 0);
		SEGMENT_3 res_seg;
		int res_idxtri = -1;
		if (res)
		{
			//std::cout << "found intersection" << std::endl;
			if (!CGAL::assign(res_point, res->first))
			{
				CGAL::assign(res_seg, res->first);
				res_point = res_seg.source();
			}
			res_idxtri = res->second - m_trilist->begin();
		}
		if (out_hitpoint)
			*out_hitpoint = res_point;
		if (out_idxtri)
			*out_idxtri = res_idxtri;
	}

	void MeshSearcher::init_with_triangular_mesh(MeshSearcher& output, const TriangularMesh& mesh)
	{
		MeshSearcher x;
		x.set_mesh(mesh, true);
		output = x;
	}

	MeshSearcher MeshSearcher::init_with_triangular_mesh(const TriangularMesh& mesh)
	{
		MeshSearcher output;
		init_with_triangular_mesh(output, mesh);
		return output;
	}

	void MeshSearcher::init_with_vertex_face(MeshSearcher& output,
		const MATRIX_d& vertices, const MATRIX_i& faces)
	{
		MeshSearcher _output;
		auto trimesh = make_shared<TriangularMesh>();
		TriangularMesh::init_with_vertex_face(*trimesh, vertices, faces);
		_output.m_own_mesh = trimesh;
		_output.set_mesh(*trimesh, true);
		output = _output;
	}

	MeshSearcher::MeshSearcher()
	{
		m_trilist = make_shared<std::vector<TRI_3>>();
	}


	MeshSearcher::~MeshSearcher()
	{
	}
}

