// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

//#include "targetver.h"

#include <stdio.h>
//#include <tchar.h>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <array>
#include <fstream>
#include <map>

#define TINYOBJLOADER_USE_DOUBLE

#include "tiny_obj_loader.h"

#include "util_cgal.h"
#include "util_cgal_eigen.h"

#include "nanoflann.hpp"

// TODO: reference additional headers your program requires here
