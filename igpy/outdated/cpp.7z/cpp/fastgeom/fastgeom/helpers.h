#pragma once

#include "stdafx.h"
#include "TriangularMesh.h"

namespace fastgeom
{
	using namespace _NS_UTILITY;
	std::vector<TriangularMesh> load_obj_as_meshlist(std::string filename);
	std::map<std::string, TriangularMesh> load_obj_as_name2mesh(std::string filename);
};
