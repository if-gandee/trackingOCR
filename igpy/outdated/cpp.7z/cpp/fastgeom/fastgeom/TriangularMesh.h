#pragma once
#include "stdafx.h"
#include "globaldefs.h"

namespace fastgeom
{
	using namespace _NS_UTILITY;

	/// <summary>
	/// The triangular mesh.
	/// When using = to copy, only copy as a reference, you need to call clone to copy the object.
	/// </summary>
	class TriangularMesh: public HeavyObject<TriangularMesh>
	{
	protected:
		//the mesh object in CGAL
		std::shared_ptr<TRIMESH_3> m_trimesh;

		//name
		std::shared_ptr<std::string> m_name;

		//mesh in matrix form
		std::shared_ptr<MATRIX_d> m_vertices;
		std::shared_ptr<MATRIX_i> m_faces;

		//UV texture coordinate
		std::shared_ptr<MATRIX_d> m_tex_vertices; //nx2, each row is a uv coordinate
		std::shared_ptr<MATRIX_i> m_tex_faces; //index into m_tex_vertices, same size as m_faces, assign a texture coordinate to each vertex in each face

		//normals
		std::shared_ptr<MATRIX_d> m_normal_vertices; //nx3, each row is a normal
		std::shared_ptr<MATRIX_i> m_normal_faces; //index into normal_vertices, the vertex normal for each vertex in each face

		//the texture image
		std::shared_ptr<ImageRGBA_d> m_texture_image;

		////vertex color
		//MATRIX_d m_color4f_vertices;
		//MATRIX_i m_color4f_faces; //index into m_color4f_vertices, same length as m_faces, assign a color to each vertex in each face

		void invalidate_cgal_mesh()
		{
			m_trimesh = nullptr;
		}
		// create CGAL mesh from vertex and face
		void update_cgal_mesh();

	public:
		// get a copy of this object
		TriangularMesh clone() const;

	public:
		TriangularMesh();
		virtual ~TriangularMesh();

		// get/set texture
		const ImageRGBA_d& get_texture_image() const { return *m_texture_image; }
		void set_texture_image(const ImageRGBA_d& val) { *m_texture_image = val; }

		// get/set name
		std::string get_name() const { return *m_name; }
		void set_name(std::string val) { *m_name = val; }

		//check if there is any vertex
		bool is_empty() const {
			return m_vertices->size() == 0;
		}

		// get/set vertex and face
		const MATRIX_d& get_vertices() const { return *m_vertices; }
		void set_vertices(const MATRIX_d& vertices)
		{
			*m_vertices = vertices;
			invalidate_cgal_mesh();
		}
		const MATRIX_i& get_faces() const { return *m_faces; }
		void set_faces(const MATRIX_i& faces)
		{
			*m_faces = faces;
			invalidate_cgal_mesh();
		}

		// get/set texture coordinate
		const MATRIX_d& get_texcoord_vertices() const { return *m_tex_vertices; }
		void set_texcoord_vertices(const MATRIX_d& tex_vertices){*m_tex_vertices = tex_vertices;}
		const MATRIX_i& get_texcoord_faces() const { return *m_tex_faces; }
		void set_texcoord_faces(const MATRIX_i& tex_faces){*m_tex_faces = tex_faces;}

		// get the cgal mesh
		std::shared_ptr<TRIMESH_3> get_cgal_trimesh()
		{
			if (m_trimesh == nullptr)			
				update_cgal_mesh();
			return m_trimesh;
		}

		//save into obj file
		void save_obj(std::string filename) const;

	public:
		// create triangular mesh from obj file
		static void init_with_objfile(TriangularMesh& output, std::string objfile);
		static TriangularMesh init_with_objfile(std::string objfile);

		// create triangular mesh from vertex and face array
		static void init_with_vertex_face(TriangularMesh& output,
			const MATRIX_d& vertices, const MATRIX_i& faces,
			const MATRIX_d* uv = 0, const MATRIX_i* uv_face = 0, 
			const MATRIX_d* normals =0, const MATRIX_i* normal_face =0);
	};
}


