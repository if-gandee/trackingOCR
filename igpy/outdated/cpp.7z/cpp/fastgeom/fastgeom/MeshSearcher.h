#pragma once
#include "TriangularMesh.h"
#include "util_cgal.h"

namespace fastgeom
{
	using namespace _NS_UTILITY;
	/// <summary>
	/// Search structures that operate on a mesh
	/// </summary>
	class MeshSearcher
	{
	private:
		//the mesh
		const TriangularMesh* m_mesh;

		//the mesh owned by this searcher
		std::shared_ptr<TriangularMesh> m_own_mesh;

		//the aabb tree
		std::shared_ptr<FACETREE_3> m_aabb_tree;

		//triangle list for use with aabb tree
		std::shared_ptr<std::vector<TRI_3>> m_trilist;

	// management
	public:
		/// <summary>
		/// update all query structures from the mesh
		/// </summary>
		void update_query_structure();

		/// <summary>
		/// set the triangular mesh in the query structure
		/// </summary>
		/// <param name="mesh">the triangular mesh</param>
		/// <param name="update">should we update the query structure?</param>
		void set_mesh(const TriangularMesh& mesh, bool update = true);

		/// <summary>
		/// get the immutable mesh, which is used to create this searcher
		/// </summary>
		/// <returns>the immutable mesh</returns>
		const TriangularMesh* get_mesh_immutable() const {
			return m_mesh;
		}

		/// <summary>
		/// get the mutable mesh created by this searcher
		/// </summary>
		/// <returns></returns>
		std::shared_ptr<TriangularMesh> get_mesh_mutable() {
			return m_own_mesh;
		}

	//query
	public:
		/// <summary>
		/// for each query point, find the closest point on the mesh
		/// </summary>
		/// <param name="pts">the query points, nx3 matrix</param>
		/// <param name="out_nnpts">output nearest point for each query point</param>
		/// <param name="out_idxtri">the index of the triangle where the nearest point lies in</param>
		/// <param name="out_bc_pts">the barycentric coordinate of each nearest point</param>
		void find_closest_point(const MATRIX_d& pts, MATRIX_d* out_nnpts, 
			VECTOR_i* out_idxtri = 0, MATRIX_d* out_bc_pts =0);

		/// <summary>
		/// find ray intersection with the mesh, return the first hit points.
		/// </summary>
		/// <param name="p0">nx3, origins of the rays</param>
		/// <param name="dirs">nx3, directions of the rays</param>
		/// <param name="out_hitpts">nx3, output hit points of each row</param>
		/// <param name="out_idxtri">1xn, output indices of the triangles that contain the hit points. If a ray has no hit point, out_idxtri[i]=-1</param>
		/// <param name="out_bcpts">nx3, barycentric coordinates of the hitpts in their triangles</param>
		void intersect_with_ray_first(const MATRIX_d& p0, const MATRIX_d& dirs, 
			MATRIX_d* out_hitpts, VECTOR_i* out_idxtri =0, MATRIX_d* out_bcpts =0);

		/// <summary>
		/// find single ray intersection with the mesh, return the first hit point.
		/// </summary>
		/// <param name="ray">the query ray</param>
		/// <param name="out_hitpoint">output hit point</param>
		/// <param name="out_idxtri">index of the triangle that contains the hit point. Equal to -1 if no hit point is found.</param>
		void intersect_with_ray_first(const RAY_3& ray, POINT_3* out_hitpoint, int* out_idxtri);

	public:
		/// <summary>
		/// create search structure from a mesh
		/// </summary>
		/// <param name="output">the output object</param>
		/// <param name="mesh">the triangular mesh</param>
		static void init_with_triangular_mesh(MeshSearcher& output, const TriangularMesh& mesh);

		/// <summary>
		/// create search structure from a mesh
		/// </summary>
		/// <param name="mesh">the triangular mesh</param>
		/// <returns>the created search structure</returns>
		static MeshSearcher init_with_triangular_mesh(const TriangularMesh& mesh);

		/// <summary>
		/// create search structure from vertex and face		
		/// </summary>
		/// <param name="output">the output object</param>
		/// <param name="vertices">nx3 vertices</param>
		/// <param name="faces">nx3 faces</param>
		static void init_with_vertex_face(MeshSearcher& output, const MATRIX_d& vertices, const MATRIX_i& faces);

	public:
		MeshSearcher();
		virtual ~MeshSearcher();
	};
};


