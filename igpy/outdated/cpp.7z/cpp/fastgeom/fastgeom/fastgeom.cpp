#include "stdafx.h"
#include "TriangularMesh.h"
#include "util_eigen.h"
#include "KDTreeSearcher.h"
#include "MeshSearcher.h"
#include "util_common.h"
#include "util_eigen.h"
#include "helpers.h"

#include <iostream>
#include <utility>
using namespace std;
using tinyobj::shape_t;
using tinyobj::material_t;
using tinyobj::attrib_t;
using namespace _NS_UTILITY;
using namespace fastgeom;

class testclass
{
public:
	int x;

	int func() { return 0; }
};

using namespace std;
int main()
{
	MATRIX_d pts = MATRIX_d::Random(100, 3);
	VECTOR_d p0 = pts.row(0);
	KDTREE_STATIC_nd kdtree = KDTREE_STATIC_nd::init_with_points(pts);
	VECTOR_d out_dist;
	VECTOR_i out_index;
	kdtree.query_ball_point(p0, 0.5, &out_dist, &out_index);

	cout << p0 << endl << endl;
	cout << out_dist << endl << endl;
	cout << out_index << endl;

	save_matrix("D:/points", pts);
	save_matrix("D:/out_index", out_index);

	return 0;
}