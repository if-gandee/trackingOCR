// export_dll.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include "export_dll.h"

//========Mesh Operate==================================================================================================
void RecalculateMeshNormal(Point3 _in_points[], int _num_v, int _in_faces[], int _num_f, Point3** new_normal, double eps)
{
	recalculate_mesh_normal(_in_points, _num_v, _in_faces, _num_f, new_normal, eps);
}

//========Texture Adjust==================================================================================================
TextureAdjust* CreateTextureAdjust()
{
	TextureAdjust* texture_adjust = new TextureAdjust;

	return texture_adjust;
}

bool InitTextureAdjust(TextureAdjust * texture_adjust, int rows, int cols)
{
	return texture_adjust->initial(rows,cols);
}

bool SetSrcMat(TextureAdjust * texture_adjust, int rows, int cols, TextureFormat type, uint8_t * img_data)
{
	return texture_adjust->set_src_mat(rows, cols, type, img_data);
}
bool SetMaskMat(TextureAdjust * texture_adjust, int rows, int cols, TextureFormat type, uint8_t * img_data)
{
	return texture_adjust->set_mask_mat(rows, cols, type, img_data);
}
bool SkinBeautification(TextureAdjust * texture_adjust, uint8_t** out_data, double d, double sigmaColor, double sigmaSpace)
{
	return texture_adjust->skin_beautification(d, sigmaColor, sigmaSpace, out_data);
}


void BilateraFilter(int rows, int cols, TextureFormat type, uint8_t** img_data, double d, double sigmaColor, double sigmaSpace)
{
	bilatera_filter(rows, cols, type, img_data, d, sigmaColor, sigmaSpace);
}
void SkinBeautification1(int rows, int cols, TextureFormat type, uint8_t** img_data, uint8_t** img_mask, double d, double sigmaColor, double sigmaSpace)
{
	skin_beautification1(rows, cols, type, img_data, img_mask, d, sigmaColor, sigmaSpace);
}


//void Whitening(int rows, int cols, TextureFormat type, uint8_t** img_data, uint8_t _new_min, uint8_t _new_max, uint8_t _new_mid)
//{
//	whitening(rows, cols, type, img_data, _new_min, _new_max, _new_mid);
//}
//

void ShowImage(int rows, int cols, TextureFormat type, unsigned char* img_data)
{
	show_image(rows, cols, type, img_data);
}
//========Acc Deform==================================================================================================
AccFiter* InitAccFiter()
{
	AccFiter* accfit = new AccFiter;

	return accfit;
}

void SetRemoveIdx(AccFiter* accfit, int** _in_array, int _num_array)
{
	accfit->set_remove_idx(_in_array,_num_array);
}

void UpdateGm(AccFiter* accfit, Point3** _in_points, int _num_v, int** _in_faces, int _num_f)
{
	accfit->update_gm(_in_points, _num_v, _in_faces, _num_f);
}

void UpdateGmTarget(AccFiter* accfit, Point3** _in_points, int _num_v)
{
	accfit->update_gm_target(_in_points, _num_v);
}
void AccDeform(AccFiter* accfit, Point3** _in_points, int _num_v, int** _in_faces, int _num_f)
{
	accfit->acc_deform(_in_points, _num_v, _in_faces, _num_f);
}

//========test ==================================================================================================
int GetNum()
{
	return 10;
}

