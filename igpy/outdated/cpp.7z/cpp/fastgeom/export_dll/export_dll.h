#pragma once

#include "def_unity2cplus.h"
#include "util_mesh_operate.h"
#include "texture_adjust.h"
#include "AccFiter.h"
#include "TextureAdjust.h"

using namespace bright_unity2cplus;
using namespace bright_mesh_operate;
using namespace bright_acc;
using namespace TEXTURE_ADJUST;


#define test_obj_API __declspec(dllimport)
//========Mesh Operate==================================================================================================
extern "C" test_obj_API  void RecalculateMeshNormal(Point3 _in_points[], int _num_v, int _in_faces[], int _num_f, Point3** new_normal, double eps);

//========Texture Adjust==================================================================================================
extern "C" test_obj_API TextureAdjust* CreateTextureAdjust();
extern "C" test_obj_API bool InitTextureAdjust(TextureAdjust * texture_adjust, int rows, int cols);
extern "C" test_obj_API bool SetSrcMat(TextureAdjust* texture_adjust, int rows, int cols, TextureFormat type, uint8_t* img_data);
extern "C" test_obj_API bool SetMaskMat(TextureAdjust* texture_adjust, int rows, int cols, TextureFormat type, uint8_t* img_data);
extern "C" test_obj_API bool SkinBeautification(TextureAdjust * texture_adjust, uint8_t** out_data, double d, double sigmaColor, double sigmaSpace);

extern "C" test_obj_API void BilateraFilter(int rows, int cols, TextureFormat type, uint8_t** img_data, double d,double sigmaColor,double sigmaSpace);
extern "C" test_obj_API void SkinBeautification1(int rows, int cols, TextureFormat type, uint8_t** img_data, uint8_t** img_mask, double d, double sigmaColor, double sigmaSpace);
//extern "C" test_obj_API  void Whitening(int rows, int cols, TextureFormat type, uint8_t** img_data, uint8_t _new_min, uint8_t _new_max, uint8_t _new_mid);
extern "C" test_obj_API  void ShowImage(int rows, int cols, TextureFormat type, unsigned char* img_data);

//========Acc Deform==================================================================================================
extern "C" test_obj_API AccFiter* InitAccFiter();
extern "C" test_obj_API void SetRemoveIdx(AccFiter* accfit, int** _in_array, int _num_array);
extern "C" test_obj_API void UpdateGm(AccFiter* accfit, Point3** _in_points, int _num_v, int** _in_faces, int _num_f);
extern "C" test_obj_API void UpdateGmTarget(AccFiter* accfit, Point3** _in_points, int _num_v);
extern "C" test_obj_API void AccDeform(AccFiter* accfit, Point3** _in_points, int _num_v, int** _in_faces, int _num_f);


//========test ==================================================================================================
extern "C" test_obj_API  int GetNum(); 