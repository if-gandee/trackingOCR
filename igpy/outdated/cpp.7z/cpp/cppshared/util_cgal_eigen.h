#pragma once
//CGAL and Eigen interop

#include "def_cgal.h"
#include "def_eigen.h"
#include "util_cgal.h"

namespace _NS_UTILITY
{
	//convert nx2 matrix to n point list
	template<typename T>
	POINTLIST_2 to_point_list_2(const MATRIX_t<T>& pts)
	{
		assert(pts.cols() >= 2);
		POINTLIST_2 ptslist;
		for (size_t i = 0; i < pts.rows(); i++)
		{
			POINT_2 p(pts(i, 0), pts(i, 1));
			ptslist.push_back(p);
		}
		return ptslist;
	}

	//convert nx3 matrix to n point list
	template<typename T>
	POINTLIST_3 to_point_list_3(const MATRIX_t<T>& pts)
	{
		assert(pts.cols() >= 3);
		POINTLIST_3 ptslist;
		for (size_t i = 0; i < pts.rows(); i++)
		{
			POINT_3 p(pts(i, 0), pts(i, 1), pts(i, 2));
			ptslist.push_back(p);
		}
		return ptslist;
	}

	//convert pointlist to matrix
	inline MATRIX_d to_matrix(const POINTLIST_3& pts)
	{
		MATRIX_d mat(pts.size(), 3);
		for (int i = 0; i < pts.size(); i++)
		{
			mat(i, 0) = pts[i].x();
			mat(i, 1) = pts[i].y();
			mat(i, 2) = pts[i].z();
		}
		return mat;
	}

	//convert facelist to matrix
	inline MATRIX_i to_matrix(const POLYFACELIST& faces)
	{
		auto ndim = faces[0].size();
		MATRIX_i mat(faces.size(), ndim);
		for (int i = 0; i < faces.size(); i++)
		{
			for (int k = 0; k < faces[i].size(); k++)
			{
				mat(i, k) = faces[i][k];
			}
		}
		return mat;
	}

	//to face list
	template<typename T>
	POLYFACELIST to_face_list(const MATRIX_t<T>& faces)
	{
		POLYFACELIST facelist;
		for (int i = 0; i < faces.rows(); i++)
		{
			POLYFACE f(faces.cols());
			for (int j = 0; j < faces.cols(); j++)
			{
				f[j] = faces(i, j);
			}
			facelist.push_back(f);
		}
		return facelist;
	}

	//create mesh
	template<typename _POINT_2, typename T1, typename T2>
	void make_trimesh_2(
		const MATRIX_t<T1>& pts,
		const MATRIX_t<T2>& faces, 
		CGAL::Surface_mesh<_POINT_2>* outmesh)
	{
		typedef CGAL::Surface_mesh<_POINT_2> _TMESH;
		typedef typename _TMESH::vertex_index VI;
		typedef typename _TMESH::face_index FI;

		//create mesh
		_TMESH trimesh;
		if (outmesh)
			outmesh->clear();
		else
			outmesh = &trimesh;

		assert(pts.cols() >= 2);
		for (int i = 0; i < pts.rows(); i++)
		{
			_POINT_2 p(pts(i, 0), pts(i, 1));
			outmesh->add_vertex(p);
		}
		for (int i = 0; i < faces.rows(); i++)
		{
			POLYFACE f(faces.cols());
			for (int j = 0; j < faces.cols(); j++)
				f[j] = faces(i, j);
			outmesh->add_face(f);
		}
	}

	//convert triangulation to point and face
	inline void read_vertex_face(const Triangulate_2::CONSTRAINED_DELAUNAY_2& cdt,
		MATRIX_d* out_vertices, MATRIX_i* out_faces)
	{
		int n_finite_verts =0;
		int n_finite_faces =0;
		for (auto it = cdt.finite_vertices_begin(); it != cdt.finite_vertices_end(); ++it)
			n_finite_verts++;

		for (auto it = cdt.finite_faces_begin(); it != cdt.finite_faces_end(); ++it)
			if(it->is_in_domain())
				n_finite_faces++;

		MATRIX_d vertices(n_finite_verts, 2);
		MATRIX_i faces(n_finite_faces, 3);
		//std::cout << "reading " << n_finite_faces << " faces" << std::endl;

		int k = 0;
		for (auto it = cdt.finite_vertices_begin(); it != cdt.finite_vertices_end(); ++it)
		{
			auto p = it->point();
			vertices(k, 0) = p.x();
			vertices(k, 1) = p.y();
			k++;
		}

		k = 0;
		for (auto it = cdt.finite_faces_begin(); it != cdt.finite_faces_end(); ++it)
		{
			//faces(k, 0) = it->vertex(0)->info();
			//faces(k, 1) = it->vertex(1)->info();
			//faces(k, 2) = it->vertex(2)->info();
			//k++;
			if (it->is_in_domain())
			{
				faces(k, 0) = it->vertex(0)->info().index;
				faces(k, 1) = it->vertex(1)->info().index;
				faces(k, 2) = it->vertex(2)->info().index;
				k++;
			}
		}

		if (out_vertices)
			*out_vertices = vertices;
		if (out_faces)
			*out_faces = faces;
	}


	inline void read_vertex_face(const TRIMESH_3& trimesh, MATRIX_d* out_vertices, MATRIX_i* out_faces)
	{
		POINTLIST_3 pts;
		POLYFACELIST faces;
		read_vertex_face(trimesh, &pts, &faces);

		if (out_vertices)
			*out_vertices = to_matrix(pts);
		if (out_faces)
			*out_faces = to_matrix(faces);
	}

	//pts is the polygon, with or without end point duplication
	inline void triangulate_polygon_2(const MATRIX_d& pts, Triangulate_2::CONSTRAINED_DELAUNAY_2* out)
	{
		POINTLIST_2 ptslist = to_point_list_2(pts);
		triangulate_polygon_2(ptslist, out);
	}
};