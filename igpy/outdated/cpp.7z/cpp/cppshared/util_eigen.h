#pragma once

#include "def_eigen.h"
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>

namespace _NS_UTILITY
{
	//read/write eigen matrix
	template <typename MATRIX>
	void load_matrix(std::string filename, MATRIX& output)
	{
		using namespace std;
		ifstream infile(filename);
		if (!infile)
			throw GENERIC_ERROR("error reading file");

		typedef typename MATRIX::RealScalar DTYPE;
		vector<DTYPE> data;
		string line;

		int nrow = 0, ncol = 0;
		while (true)
		{
			if (!getline(infile, line)) break; //end of file
			istringstream is(line);
			DTYPE x;
			while (is >> x)
			{
				data.push_back(x);
			}
			if (is.fail() && !is.eof())
				throw GENERIC_ERROR("file format is wrong");
			nrow++;
		}

		if (data.size() == 0)
		{
			//empty file?
			output.resize(0, 0);
			return;
		}

		//determine matrix dimension
		ncol = data.size() / nrow;
		if (nrow * ncol != data.size())
			throw GENERIC_ERROR("not a rectangular matrix");

		//fill in the matrix
		output.resize(nrow, ncol);
		for (int i = 0; i < nrow; i++)
			for (int j = 0; j < ncol; j++)
			{
				output(i, j) = data[i*ncol + j];
			}

		infile.close();
	}

	template <typename MATRIX>
	void save_matrix(std::string filename, const MATRIX& input)
	{
		//open the file
		using namespace std;
		ofstream outfile(filename, ios::trunc);
		if (!outfile.is_open())
			throw GENERIC_ERROR("error opening file for output");

		auto nrow = input.rows();
		auto ncol = input.cols();
		for (int i = 0; i < nrow; i++)
		{
			for (int j = 0; j < ncol; j++)
			{
				outfile << input(i, j);
				if (j < ncol - 1)
					outfile << " ";
			}
			if (i < nrow - 1)
				outfile << endl;
		}
		outfile.close();
	}

	template<typename T>
	void to_vector(const std::vector<T>& input, VECTOR_t<T>* output)
	{
		output->resize(input.size());
		for (int i = 0; i < input.size(); i++)
			(*output)(i) = input[i];
	}

	template<typename T>
	VECTOR_t<T> to_vector(const std::vector<T>& input)
	{
		VECTOR_t<T> output;
		output.resize(input.size());
		for (int i = 0; i < input.size(); i++)
			output(i) = input[i];
		return output;
	}

	//parse a string containing multiple numbers into a vector
	//the numbers are delimited by any character contained in delimiters
	//NOTE: delimiters contains multiple delimiters where delimiters[i] is the i-th delimiter
	template<typename T>
	void parse_as_vector(std::string content, VECTOR_t<T>* output, std::string delimiters = " ")
	{
		//replace all delimiters as space
		for (char x : delimiters)
		{
			std::replace(content.begin(), content.end(), x, ' ');
		}

		//parse
		T x;
		std::istringstream is(content);
		std::vector<T> data;
		while (is >> x)
		{
			data.push_back(x);
		}
		*output = Eigen::Map<VECTOR_t<T>>(data.data(), data.size());
	}

	//get submatrix by rows and cols
	template<typename MAT_TYPE, typename IDXLIST_T_1, typename IDXLIST_T_2>
	MAT_TYPE get_sub_matrix(const MAT_TYPE& mat, const IDXLIST_T_1& idxrow, const IDXLIST_T_2& idxcol)
	{
		MAT_TYPE submat(idxrow.size(), idxcol.size());
		for(size_t i=0; i<idxrow.size(); i++)
			for (size_t j = 0; j < idxcol.size(); j++)
			{
				submat(i, j) = mat(idxrow[i], idxcol[j]);
			}
		return submat;
	}

	//get submatrix with multiple rows and a single column, if idxcol=-1, then all columns are retrieved
	template<typename T, typename IDX_LIST_TYPE>
	MATRIX_t<T> get_sub_matrix(const MATRIX_t<T>& mat, const IDX_LIST_TYPE& idxrow, int idxcol)
	{
		std::vector<size_t> col_index;
		if (idxcol >= 0)
			col_index.push_back(idxcol);
		else
			for (size_t i = 0; i < mat.cols(); i++)
				col_index.push_back(i);
		return get_sub_matrix(mat, idxrow, col_index);
	}

}