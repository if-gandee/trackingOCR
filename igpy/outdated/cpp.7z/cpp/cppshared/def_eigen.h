//Eigen-related definitions
#pragma once
#include <Eigen/Eigen>
#include "def_master.h"

namespace _NS_UTILITY
{
	template <typename T>
	using MATRIX_t = Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;

	template<typename T>
	using VECTOR_t = Eigen::Matrix<T, Eigen::Dynamic, 1>;

	typedef Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> MATRIX_f;
	typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> MATRIX_d;
	typedef Eigen::Matrix<int, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> MATRIX_i;

	typedef Eigen::SparseMatrix<double, Eigen::RowMajor> SP_MATRIX_d;
	typedef Eigen::SparseMatrix<float, Eigen::RowMajor> SP_MATRIX_f;
	typedef Eigen::SparseMatrix<int, Eigen::RowMajor> SP_MATRIX_i;
	typedef Eigen::SparseMatrix<uint8_t, Eigen::RowMajor> SP_MATRIX_u8;

	typedef Eigen::Matrix<float, Eigen::Dynamic, 1> VECTOR_f;
	typedef Eigen::Matrix<double, Eigen::Dynamic, 1> VECTOR_d;
	typedef Eigen::Matrix<int, Eigen::Dynamic, 1> VECTOR_i;
	typedef Eigen::Matrix<uint8_t, Eigen::Dynamic, 1> VECTOR_u8;

	typedef Eigen::AngleAxisd AngelAxis_d;

	typedef Eigen::Vector3d Vector3_d;

	typedef Eigen::Matrix3d Matrix3_d;

	template<typename T>
	class ImageRGBA_t
	{
	public:
		ImageRGBA_t<T>() {}
		ImageRGBA_t<T>(int width, int height)
		{
			resize(width, height);
			clear(0, 0, 0, 0);
		}

		MATRIX_t<T> r, g, b, a;
		void resize(int width, int height)
		{
			r.resize(height, width);
			g.resize(height, width);
			b.resize(height, width);
			a.resize(height, width);
		}

		void clear(T r, T g, T b, T a)
		{
			this->r.fill(r);
			this->g.fill(g);
			this->b.fill(b);
			this->a.fill(a);
		}
	};

	using ImageRGBA_d = ImageRGBA_t<double>;
	using ImageRGBA_f = ImageRGBA_t<float>;
	using ImageRGBA_u = ImageRGBA_t<uint8_t>;
	using ImageRGBA_i = ImageRGBA_t<int>;
};