#pragma once

#ifndef _NS_UTILITY
#define _NS_UTILITY james
#endif

#include <string>
namespace _NS_UTILITY
{
	typedef std::string GENERIC_ERROR;
	
	inline void assert_throw(bool expr, std::string msg)
	{
		if (!expr)
			throw std::logic_error(msg.c_str());
	}
}