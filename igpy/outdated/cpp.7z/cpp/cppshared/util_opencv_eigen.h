#pragma once
#include "def_master.h"
#include "def_eigen.h"
#include "opencv2/core.hpp"
#include "opencv2/features2d.hpp"

namespace _NS_UTILITY
{
	template<typename T>
	void to_matrix(const cv::Mat& src, MATRIX_t<T>& dst)
	{
		auto cvtype = cv::DataType<T>::type;
		int nrow = src.rows;
		int ncol = src.cols;
		if (cvtype == src.type())
		{
			dst = Eigen::Map<MATRIX_t<T>>((T*)src.data, nrow, ncol);
		}
		else
		{
			cv::Mat srcnew;
			src.convertTo(srcnew, cvtype);
			dst = Eigen::Map<MATRIX_t<T>>((T*)srcnew.data, nrow, ncol);
		}
	}

	//convert a list of key points to a nx2 matrix
	template<typename T>
	void to_matrix(const std::vector<cv::KeyPoint>& kps, MATRIX_t<T>& dst)
	{
		dst.setZero(kps.size(), 2);
		for (int i = 0; i < kps.size(); i++)
		{
			dst(i, 0) = kps[i].pt.x;
			dst(i, 1) = kps[i].pt.y;
		}
	}
};
