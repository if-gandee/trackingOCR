#pragma once

#include "def_master.h"
#include <vector>
#include <map>
#include <algorithm>
#include <iostream>

namespace _NS_UTILITY
{
	//split the range of integers [min,max] into n groups,
	//the range of i-th group is [output[i].first, output[i].second]
	inline std::vector< std::pair<int, int> > split_indices_by_n(int min, int max, int n)
	{
		std::vector< std::pair<int, int> > endpts;
		if (min > max)
			return endpts;
		double dx = double(max - min) / n;

		std::pair<int, int> p;
		p.first = min;
		for (int i = 1; i <= n; i++)
		{
			int e = int(min + i*dx);
			if (e < p.first) //this slot is not usable
				continue;

			//a new slot is created
			p.second = e;
			endpts.push_back(p);

			//prepare the new slot
			p.first = p.second + 1;
		}

		//done
		return endpts;
	}

	/// <summary>
	/// sort the data in ascending or descending order, return the sorted index
	/// </summary>
	template<typename T>
	std::vector<size_t> sort_index(const std::vector<T>& data,
		bool is_ascending = true, bool is_stable = false)
	{
		//sort the index by data
		std::vector<size_t> idx(data.size());
		for (size_t i = 0; i < idx.size(); i++)
			idx[i] = i;

		auto cmp = [&](size_t x, size_t y)
		{
			return data[x] < data[y];
		};

		if (is_stable)
			std::stable_sort(idx.begin(), idx.end(), cmp);
		else
			std::sort(idx.begin(), idx.end(), cmp);

		if (!is_ascending)
			std::reverse(idx.begin(), idx.end());
		return idx;
	}

	/// <summary>
	/// find unique elements in an array
	/// </summary>
	/// <param name="data">the data to the processed</param>
	/// <param name="out_index">indices into the data where the unique elements are, such that out_unique = data[out_index]</param>
	/// <param name="out_inverse_index">indices into the unique elements that can recover the data, 
	/// such that data=out_unique[out_reverse_index]</param>
	/// <returns>std::vector of the unique elements</returns>
	template<typename T>
	std::vector<T> unique_elements(const std::vector<T>& data,
		std::vector<size_t>* out_index = 0,
		std::vector<size_t>* out_inverse_index = 0)
	{
		auto idx = sort_index(data);
		std::vector<size_t> u_index;
		std::vector<size_t> inv_index(idx.size());

		if (idx.size() > 0)
		{
			u_index.push_back(idx[0]);
			inv_index[idx[0]] = 0;

			for (size_t i = 1; i < idx.size(); i++)
			{
				auto idx_prev = idx[i - 1];
				auto idx_this = idx[i];

				//found new unique element
				if (data[idx_this] != data[idx_prev])
				{
					u_index.push_back(idx_this);
				}

				inv_index[idx_this] = u_index.size() - 1;
			}
		}

		//collect all unique elements
		std::vector<T> u_elem(u_index.size());
		for (size_t i = 0; i < u_index.size(); i++)
		{
			u_elem[i] = data[u_index[i]];
		}

		if (out_index)
			*out_index = u_index;
		if (out_inverse_index)
			*out_inverse_index = inv_index;
		return u_elem;
	}

	template<typename ITER>
	void print_container(ITER it_begin, ITER it_end, int n_per_line = -1)
	{
		int n_print = 0;
		for (auto it = it_begin; it != it_end; ++it)
		{
			n_print++;
			std::cout << *it << ", ";

			if (n_per_line > 0 && (n_print % n_per_line == 0))
			{
				std::cout << std::endl;
			}
		}
		std::cout << std::endl;
	}

	template<typename CONTAINER>
	void print_container(const CONTAINER& data, int n_per_line = -1)
	{
		print_container(data.begin(), data.end(), n_per_line);
	}

	/// <summary>
	/// get elements by indexing into an array, such that output[i]=data[*(it_idx_begin+i)]
	/// </summary>
	/// <param name="data"> the data array</param>
	/// <param name="it_idx_begin">iterator into the begin of the index array</param>
	/// <param name="it_idx_end">iterator into one past the end of the index array</param>
	/// <returns>the retrieved array such that output[i]=data[*(it_idx_begin+i)]</returns>
	template<typename T, typename ITER>
	std::vector<T> get_element_by_index(const std::vector<T>& data, ITER it_idx_begin, ITER it_idx_end)
	{
		auto n = std::distance(it_idx_begin, it_idx_end);
		std::vector<T> output(n);
		size_t k = 0;
		for (auto it = it_idx_begin; it != it_idx_end; ++it)
			output[k++] = data[*it];
		return output;
	}
}