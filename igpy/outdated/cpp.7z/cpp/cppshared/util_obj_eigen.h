#pragma once
//read/write obj file with eigen

#include "util_common.h"
#include "util_eigen.h"
#include "thirdparty/tiny_obj_loader.h"
#include <string>
#include <vector>

namespace _NS_UTILITY
{
	class _MyTrimesh
	{
	public:
		MATRIX_d vertices;
		MATRIX_i faces;

		//let uv_faces[i]=(a,b,c), faces[i]=(x,y,z),  
		//then uv[a] is the texture coordinate for vertices[x] on i-th face
		MATRIX_d uv;
		MATRIX_i uv_faces;

		//just like uv, but for normals
		MATRIX_d normals;
		MATRIX_i normal_faces;

		std::string name;
	};

	/// <summary>
	/// load .obj file and treat the contents as a single mesh.
	/// </summary>
	/// <param name="objfile">the filename</param>
	/// <param name="out_vertices">output vertices</param>
	/// <param name="out_faces">output faces</param>
	/// <param name="out_uv">output uv coordinates</param>
	/// <param name="out_uv_faces">output uv faces</param>
	/// <param name="out_normals">output normals</param>
	/// <param name="out_normal_faces">output normal faces</param>
	inline void load_obj_single_mesh(std::string objfile,
		MATRIX_d* out_vertices, MATRIX_i* out_faces,
		MATRIX_d* out_uv = 0, MATRIX_i* out_uv_faces = 0,
		MATRIX_d* out_normals = 0, MATRIX_i* out_normal_faces = 0)
	{
		using namespace std;
		using tinyobj::shape_t;
		using tinyobj::material_t;
		using tinyobj::attrib_t;

		vector<shape_t> shapes;
		vector<material_t> materials;
		attrib_t attrib;
		string err;

		bool ret = tinyobj::LoadObj(&attrib, &shapes, &materials, &err, objfile.c_str());
		assert_throw(ret, "error when reading file " + objfile);

		// read shapes
		bool has_normal = attrib.normals.size() > 0;
		bool has_texcoord = attrib.texcoords.size() > 0;

		// read face matrix
		vector<int> arr_face;
		vector<int> arr_texface;
		vector<int> arr_normalface;
		for (auto& s : shapes)
		{
			auto& idx = s.mesh.indices;
			for (int i = 0; i < idx.size(); i++)
			{
				arr_face.push_back(idx[i].vertex_index);
				if (has_texcoord)
					arr_texface.push_back(idx[i].texcoord_index);
				if (has_normal)
					arr_normalface.push_back(idx[i].normal_index);
			}
		}
		MATRIX_i faces = Eigen::Map<MATRIX_i>(arr_face.data(), arr_face.size() / 3, 3);

		// read vertices
		int n_vert = attrib.vertices.size() / 3;
		typedef decltype(attrib.vertices)::value_type v_type;
		MATRIX_d vertices = Eigen::Map<MATRIX_t<v_type>>(attrib.vertices.data(), n_vert, 3).cast<double>();

		// read texcoord
		MATRIX_d texcoord;
		MATRIX_i texfaces;
		if (has_texcoord)
		{
			texcoord = Eigen::Map<MATRIX_t<v_type>>(attrib.texcoords.data(), attrib.texcoords.size() / 2, 2).cast<double>();
			texfaces = Eigen::Map<MATRIX_i>(arr_texface.data(), arr_texface.size() / 3, 3);
		}

		// read normal
		MATRIX_d normals;
		MATRIX_i normalfaces;
		if (has_normal)
		{
			normals = Eigen::Map<MATRIX_t<v_type>>(attrib.normals.data(), attrib.normals.size() / 3, 3).cast<double>();
			normalfaces = Eigen::Map<MATRIX_i>(arr_normalface.data(), arr_normalface.size() / 3, 3);
		}

		if (out_vertices)
			*out_vertices = vertices;
		if (out_faces)
			*out_faces = faces;
		if (out_uv)
			*out_uv = texcoord;
		if (out_uv_faces)
			*out_uv_faces = texfaces;
		if (out_normals)
			*out_normals = normals;
		if (out_normal_faces)
			*out_normal_faces = normalfaces;
	}

	/// <summary>
	/// load .obj file and treat the contents as a single mesh.
	/// </summary>
	/// <param name="objfile">obj file name</param>
	/// <returns>a _MyTrimesh object containing the mesh information</returns>
	inline _MyTrimesh load_obj_single_mesh(std::string objfile)
	{
		_MyTrimesh output;
		load_obj_single_mesh(objfile, &output.vertices, &output.faces,
			&output.uv, &output.uv_faces, &output.normals, &output.normal_faces);
		return output;
	}

	/// <summary>
	/// load .obj file and respect the mesh separations in the file
	/// </summary>
	/// <param name="filename">obj file name</param>
	/// <returns>a list of _MyTrimesh</returns>
	inline std::vector<_MyTrimesh> load_obj_multi_mesh(std::string filename)
	{
		using namespace std;
		using tinyobj::shape_t;
		using tinyobj::material_t;
		using tinyobj::attrib_t;

		vector<shape_t> shapes;
		vector<material_t> materials;
		attrib_t attrib;
		string err;
		std::vector<_MyTrimesh> output;

		bool ret = tinyobj::LoadObj(&attrib, &shapes, &materials, &err, filename.c_str());
		assert_throw(ret, "error when reading file " + filename);

		// read shapes
		bool has_normal = attrib.normals.size() > 0;
		bool has_texcoord = attrib.texcoords.size() > 0;

		// read face matrix
		for (auto& s : shapes)
		{
			auto& idx = s.mesh.indices;
			vector<int> arr_face;
			arr_face.reserve(idx.size());

			vector<int> arr_texface;
			if (has_texcoord)
				arr_face.reserve(idx.size());

			vector<int> arr_normalface;
			if (has_normal)
				arr_normalface.reserve(idx.size());

			for (int i = 0; i < idx.size(); i++)
			{
				arr_face.push_back(idx[i].vertex_index);
				if (has_texcoord)
					arr_texface.push_back(idx[i].texcoord_index);
				if (has_normal)
					arr_normalface.push_back(idx[i].normal_index);
			}

			auto get_vertex_face_re_index = [](
				tinyobj::real_t* rawdata,
				int n_col,
				const vector<int>& arr_face,
				MATRIX_d& out_vertices,
				MATRIX_i& out_faces)
			{
				//re-index face array
				std::vector<size_t> relb_arr_face;
				auto u_idx_vertex = unique_elements(arr_face, 0, &relb_arr_face);
				out_vertices.resize(u_idx_vertex.size(), n_col);
				for (int i = 0; i < u_idx_vertex.size(); i++)
				{
					for (int k = 0; k < n_col; k++)
					{
						int idx = u_idx_vertex[i];
						out_vertices(i, k) = rawdata[n_col * idx + k];
					}
				}
				out_faces = Eigen::Map<MATRIX_t<size_t>>(relb_arr_face.data(), relb_arr_face.size() / 3, 3).cast<int>();
			};

			//re-index face array
			MATRIX_d vertices;
			MATRIX_i faces;
			get_vertex_face_re_index(attrib.vertices.data(), 3, arr_face, vertices, faces);

			//re-index texture array
			MATRIX_d texcoord;
			MATRIX_i texfaces;
			if (has_texcoord)
			{
				get_vertex_face_re_index(attrib.texcoords.data(), 2, arr_texface, texcoord, texfaces);
			}

			//re-index normal array
			MATRIX_d normals;
			MATRIX_i normalfaces;
			if (has_normal)
			{
				get_vertex_face_re_index(attrib.normals.data(), 3, arr_normalface, normals, normalfaces);
			}

			_MyTrimesh obj;
			obj.vertices = vertices;
			obj.faces = faces;
			obj.uv = texcoord;
			obj.uv_faces = texfaces;
			obj.normals = normals;
			obj.normal_faces = normalfaces;
			obj.name = s.name;
			output.push_back(obj);
		}
		return output;
	}
};